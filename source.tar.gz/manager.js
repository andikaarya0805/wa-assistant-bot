import makeWASocket, { 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    jidDecode 
} from '@whiskeysockets/baileys';

import pino from 'pino';
import express from 'express';
import qrcode from 'qrcode-terminal';
import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import NodeCache from 'node-cache';
const msgRetryCounterCache = new NodeCache();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import geminiService from './services/geminiService.js';
import { pullSession, pushSession, deleteSession } from './services/supabaseService.js';
const aiService = geminiService;

const app = express();
const PORT = process.env.PORT || 8000;
const SESSION_PATH = './baileys_auth';
let latestQR = null;

// --- Data Storage ---
const users = {};
const cooldowns = new Map();
const errorSilence = new Map();

const getUser = (id) => {
    if (!users[id]) users[id] = {
        isAfk: false,
        afkReason: "",
        history: [],
        excludeList: new Set(),
        interactedUsers: new Set()
    };
    return users[id];
};

const userObj = getUser('system'); // Global system state

// --- Helpers ---
const decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
        const decode = jidDecode(jid) || {};
        return decode.user && decode.server && `${decode.user}@${decode.server}` || jid;
    }
    return jid;
};

// --- Connection Logic ---
let isConnecting = false;

async function startBot(startFresh = false) {
    if (isConnecting) return;
    isConnecting = true;

    console.log("[System] Initializing Baileys Bot (ESM Mode)...");
    let hasQR = false;
    
    try {
        // 1. Pull Session from Supabase (only if NOT forcing fresh start)
        if (!startFresh) {
            await pullSession();
        } else {
            console.log("[System] Forcing fresh start (skipping session pull)...");
        }

        const { state, saveCreds } = await useMultiFileAuthState(SESSION_PATH);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            auth: state,
            browser: ["Mac OS", "Chrome", "121.0.6167.139"],
            markOnlineOnConnect: true,
            connectTimeoutMs: 120000,
            defaultQueryTimeoutMs: 0,
            msgRetryCounterCache
        });

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr && !hasQR) {
                hasQR = true;
                console.log("[System] Scan QR Code required...");
                qrcode.generate(qr, { small: true });
                latestQR = qr;
                const qrLink = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(qr)}&size=300x300`;
                console.log(`[Link Alternatif] ${qrLink}`);
            }

            if (connection === 'close') {
                isConnecting = false;
                const error = lastDisconnect?.error;
                const statusCode = error?.output?.statusCode || error?.statusCode;
                
                // Reconnect on everything except Logout (401)
                let shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                // Special case for 515: Always reconnect without clearing session
                if (statusCode === 515) shouldReconnect = true;

                console.log(`[System] Connection Closed!`);
                console.log(`[System] - Status: ${statusCode}`);
                console.log(`[System] - Message: ${error?.message}`);
                console.log(`[System] - Reconnect: ${shouldReconnect}`);

                // Handle Logout (401) or Conflict (440) or Restart Required (515)
                // Handle Logout (401) or Conflict (440)
                // 515 is "Stream Errored" (restart required), NOT logic for deletion.
                if (
                    statusCode === DisconnectReason.loggedOut || 
                    statusCode === 440
                ) {
                    console.log(`[System] Critical Error (${statusCode}). Clearing session to force fresh login...`);
                    if (fs.existsSync(SESSION_PATH)) fs.rmSync(SESSION_PATH, { recursive: true, force: true });
                    await deleteSession(); // Clear from Supabase too
                    
                    console.log("[System] Restarting in fresh mode in 5 seconds...");
                    setTimeout(() => startBot(true), 5000); // Force fresh start
                    return;
                }

                if (shouldReconnect) {
                    console.log("[System] Reconnecting in 5 seconds...");
                    setTimeout(() => startBot(false), 5000);
                }
            } else if (connection === 'open') {
                isConnecting = false;
                console.log('🚀 WhatsApp Bot is Ready! (Baileys Mode)');
                // Sync session to Supabase immediately
                await pushSession();
            }
        });

        // Debounced Creds Update to avoid spamming Supabase
        let credsTimeout;
        sock.ev.on('creds.update', async () => {
            await saveCreds();
            clearTimeout(credsTimeout);
            credsTimeout = setTimeout(async () => {
                console.log("[System] Periodic session sync to Supabase...");
                await pushSession();
            }, 30000); // 30 seconds debounce
        });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        const msg = messages[0];
        if (!msg.message || msg.key.remoteJid === 'status@broadcast') return;

        const senderJid = msg.key.remoteJid;
        const isMe = msg.key.fromMe;
        const body = msg.message.conversation || 
                     msg.message.extendedTextMessage?.text || 
                     msg.message.imageMessage?.caption || "";
        
        const isGroup = senderJid.endsWith('@g.us');
        const senderNumber = decodeJid(senderJid);

        // --- Commands (Owner only) ---
        const cmd = body.trim().toLowerCase();
        if (isMe) {
            if (cmd.startsWith('!afk')) {
                const reason = body.slice(4).trim();
                userObj.isAfk = true;
                userObj.afkReason = reason || "";
                console.log(`>> AFK Mode Activated${reason ? ' for: ' + reason : ''}`);
                try {
                    const reply = `🔇 *AFK Mode ON*.${reason ? '\nKeperluan: ' + reason : ''}\nBot bakal bales chat otomatis.`;
                    await sock.sendMessage(senderJid, { text: reply }, { quoted: msg });
                } catch (e) {
                    console.error("Failed to send AFK ON message:", e);
                }
                return;
            }
            if (cmd === '!back') {
                userObj.isAfk = false;
                userObj.afkReason = "";
                userObj.interactedUsers.clear();
                console.log(`>> AFK Mode Deactivated`);
                try {
                    await sock.sendMessage(senderJid, { text: '🔊 *AFK Mode OFF*. Bot berhenti bales chat.' }, { quoted: msg });
                } catch (e) {
                    console.error("Failed to send AFK OFF message:", e);
                }
                return;
            }

            if (cmd === '!nuke') {
                console.log(`>> NUKE COMMAND RECEIVED. Wiping session...`);
                try {
                    await sock.sendMessage(senderJid, { text: '☢️ *NUKE INITIATED*. Menghapus sesi dan restart...' }, { quoted: msg });
                } catch (e) { console.error("Failed to send NUKE msg:", e); }
                
                await deleteSession();
                try {
                    if (fs.existsSync(SESSION_PATH)) fs.rmSync(SESSION_PATH, { recursive: true, force: true });
                } catch (e) { console.error("Failed to delete local session:", e); }
                
                console.log(`>> Session wiped. Restarting...`);
                process.exit(0); // Force restart to generate new session
            }

            if (cmd.startsWith('!block')) {
                const target = body.slice(6).trim();
                if (!target) return sock.sendMessage(senderJid, { text: '⚠️ Kasih nomornya dong. Contoh: `!block 628123456789`' }, { quoted: msg });
                const targetJid = target.includes('@') ? target : `${target}@s.whatsapp.net`;
                userObj.excludeList.add(targetJid);
                console.log(`>> Blocked: ${targetJid}`);
                return sock.sendMessage(senderJid, { text: `✅ Berhasil mengecualikan @${target.split('@')[0]} dari bot.`, mentions: [targetJid] }, { quoted: msg });
            }

            if (cmd.startsWith('!unblock')) {
                const target = body.slice(8).trim();
                if (!target) return sock.sendMessage(senderJid, { text: '⚠️ Kasih nomornya dong.' }, { quoted: msg });
                const targetJid = target.includes('@') ? target : `${target}@s.whatsapp.net`;
                userObj.excludeList.delete(targetJid);
                console.log(`>> Unblocked: ${targetJid}`);
                return sock.sendMessage(senderJid, { text: `✅ @${target.split('@')[0]} sudah tidak lagi dikecualikan.`, mentions: [targetJid] }, { quoted: msg });
            }

            if (cmd === '!listblock') {
                if (userObj.excludeList.size === 0) return sock.sendMessage(senderJid, { text: '📭 Daftar pengecualian kosong.' }, { quoted: msg });
                let text = '🚫 *Daftar Pengecualian:*\n\n';
                userObj.excludeList.forEach(num => text += `- @${num.split('@')[0]}\n`);
                return sock.sendMessage(senderJid, { text, mentions: Array.from(userObj.excludeList) }, { quoted: msg });
            }
        }

        // --- AFK Response Logic ---
        if (!userObj.isAfk || isMe) return;

        // Check if sender is in Exclusion List
        if (userObj.excludeList.has(senderJid)) {
            console.log(`[Skipped] Sender ${senderJid} is in exclusion list.`);
            return;
        }

        // Bot behavior: Reply to DM or Tagged in Group
        const botId = decodeJid(sock.user.id);
        const isTagged = body.includes(`@${botId.split('@')[0]}`);

        if (isGroup && !isTagged) return;

        // Get user-specific data (for history)
        const chatObj = getUser(senderJid);

        // Rate Limiting & Error Silence
        const now = Date.now();
        if (errorSilence.has(senderNumber) && now < errorSilence.get(senderNumber)) return;
        if (cooldowns.has(senderNumber) && (now - cooldowns.get(senderNumber)) < 5000) return;
        cooldowns.set(senderNumber, now);

        console.log(`[Userbot] Processing chat from ${senderNumber}: ${body.substring(0, 50)}...`);

        const ownerName = process.env.OWNER_NAME || "𝚍𝚞𝚖𝚙𝚒𝚢𝚎𝚢";
        const isFirstMessage = !userObj.interactedUsers.has(senderNumber);

        try {
            const reply = await aiService.generateContent(body, chatObj.history, ownerName, isFirstMessage, userObj.afkReason);
            
            if (isFirstMessage) userObj.interactedUsers.add(senderNumber);

            // Update History (Max 10 messages)
            chatObj.history.push({ role: "user", parts: [{ text: body }] });
            chatObj.history.push({ role: "model", parts: [{ text: reply }] });
            if (chatObj.history.length > 10) chatObj.history = chatObj.history.slice(-10);

            await sock.sendMessage(senderJid, { text: reply }, { quoted: msg });
        } catch (e) {
            console.error(`[AI Error]:`, e.message);
            if (e.message?.includes('429')) errorSilence.set(senderNumber, now + 60000);
        }
        });
    } catch (e) {
        isConnecting = false;
        console.error("[System] startBot Fatal Error:", e.message);
        setTimeout(() => startBot(), 10000);
    }
}

// Start bot
startBot();

// --- Health Check ---
app.get('/health', (req, res) => res.json({ status: 'alive', mode: 'baileys' }));
app.get('/qr', async (req, res) => {
    if (!latestQR) return res.send("QR Code belum tersedia atau bot sudah login. Coba refresh beberapa saat lagi.");
    try {
        const qrImage = await QRCode.toBuffer(latestQR);
        res.type('image/png');
        res.send(qrImage);
    } catch (e) {
        res.status(500).send("Gagal generate QR Image");
    }
});
app.listen(PORT, () => console.log(`Health server running on port ${PORT}`));

// Global Error Handling
process.on('uncaughtException', (err) => console.error('CRASH:', err));
process.on('unhandledRejection', (reason) => console.error('REJECTION:', reason));
